#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re, os, gc, json
from pathlib import Path
from datetime import datetime
import pandas as pd
from tqdm import tqdm
from sklearn.metrics import classification_report, confusion_matrix
import torch
from transformers import pipeline

# -------- 0. 基础路径（仅此处改） --------
os.environ["CUDA_VISIBLE_DEVICES"] = "4"
CSV_PATH   = "/data/yangzhifei/pro/ML_SATD/dataset/sampled_label_dataset_normalized_rmvtodo.csv"
MODEL_PATH = "/data/yangzhifei/pro/ML_SATD/models/gpt-oss-20b"   # 或 "openai/gpt-oss-20b"

# 目录名包含时间戳 + 模型名
MODEL_NAME = Path(MODEL_PATH).name
RUN_DIR    = Path("results") / f"run-{datetime.now():%Y%m%d-%H%M%S}-{MODEL_NAME}"
RUN_DIR.mkdir(parents=True, exist_ok=True)

# -------- 1. 其它参数 --------
PRINT_UNPARSED    = True
FALLBACK_ABBR     = "Data Conf"
MAX_NEW_TOKENS    = 32768     # 分类阶段：保持不变
MAX_INPUT_TOKENS  = 4096
REASON_MAX_NEW_TOKENS = 512   # 仅用于 reason，可适度加长以避免截断

# ----------------- 标签映射（全称 -> 缩写） -----------------
LABEL_ABBR = {
    "Machine Learning Knowledge":"MLKnow","Model Interpretability":"MLInter",
    "Model Code Comprehension":"MCC","Duplicate Model Code":"DMC",
    "Duplicate Feature Extraction Code":"DFEC","Weight Configuration":"Weight Conf",
    "Layer Configuration":"Layer Conf","Hyper-parameter Configuration":"HP Conf",
    "Code Dependency":"MLDepend","Glue Code":"GC","Custom Data Type":"CDT",
    "Multiple Languages":"ML","Unnecessary Model Code":"UMC",
    "Data Processing Configuration":"Data Conf","Plain Old Data Type":"PODT",
    "Data Storage Configuration":"DS Conf","Abstraction":"Abs","Boundary Erosion":"BE",
    "Model Code Modifiability":"MCM","Model Code Reusability":"MCR",
    "Prediction Quality":"PQ","Machine Learning Reliability":"MLRelia","Prototype":"Proto",
}
LABELS      = list(LABEL_ABBR.keys())
ABBR_SET    = set(LABEL_ABBR.values())
ABBR2FULL   = {abbr: full for full, abbr in LABEL_ABBR.items()}
FULL2ABBR   = LABEL_ABBR

# 规范化工具：去掉所有非字母，转小写
def _canon(s: str) -> str:
    return re.sub(r"[^a-z]", "", s.lower())

# 规范化字典：任意“全称/缩写/大小写/空格变体” → 全称
FULL_BY_CANON = {_canon(full): full for full in LABELS}
FULL_BY_ABBR_CANON = {_canon(abbr): full for full, abbr in LABEL_ABBR.items()}

def normalize_to_full(label: str):
    if not isinstance(label, str):
        return None
    s = label.strip()
    if s in LABELS:
        return s
    if s in ABBR2FULL:
        return ABBR2FULL[s]
    cz = _canon(s)
    if cz in FULL_BY_CANON:
        return FULL_BY_CANON[cz]
    if cz in FULL_BY_ABBR_CANON:
        return FULL_BY_ABBR_CANON[cz]
    return None

# ============ 2. Prompt（简洁 + 强约束） ============
PROMPT_HEAD = r"""
There are 23 types of Machine Learning (ML) Self-Admitted Technical Debt (SATD):

MACHINE LEARNING KNOWLEDGE (MLKnow): Machine-learning software carries plenty of unique challenges. Uneducated solutions by unaware developers may have to be revisited.

MODEL INTERPRETABILITY (MLInter): Machine-learning models are a black box, causing poor understanding of model functionality; this can lead to unknown behaviour.

MODEL CODE COMPREHENSION (MCC): Model code carries extra legibility concerns not present in traditional software (e.g., poorly-named temporary matrix variables).

DUPLICATE MODEL CODE (DMC): Code duplication frequently occurs in model code.

DUPLICATE FEATURE EXTRACTION CODE (DFEC): Code duplication frequently occurs in feature-extraction code.

WEIGHT CONFIGURATION (Weight Conf): Editing code that involves the weights of a model, or configuring a model's weights directly.

LAYER CONFIGURATION (Layer Conf): Editing code that deals with model layers, or configuring layers themselves.

HYPER-PARAMETER CONFIGURATION (HP Conf): Configuring hyper-parameters of a model, or editing default values of off-the-shelf models.

CODE DEPENDENCY (MLDepend): A needed change is blocked by an external dependency (library / subsystem).

GLUE CODE (GC): Supporting code written to interface with other code, inhibiting improvements due to dependent peculiarities.

CUSTOM DATA TYPE (CDT): Using data types provided by general-purpose packages can cause extensive inter-operability burden.

MULTIPLE LANGUAGES (ML): Components written in other languages may introduce difficulties in ML development.

UNNECESSARY MODEL CODE (UMC): Model code that bottlenecks execution, is unreachable / deprecated, or is unnecessary and should be removed.

DATA PROCESSING CONFIGURATION (Data Conf): Configuring how data is processed, by editing the data directly or adding new processing steps.

PLAIN OLD DATA TYPE (PODT): Using raw data types in ML causes confusion when interpreting processes.

DATA STORAGE CONFIGURATION (DS Conf): Configuring how data is represented internally or stored externally.

ABSTRACTION (Abs): Lack of abstractions in ML systems causes cascading changes when a component is modified.

BOUNDARY EROSION (BE): Lack of boundaries between subsystems complicates maintenance and isolates changes poorly.

MODEL CODE MODIFIABILITY (MCM): Model code should enable easy maintenance and future modifications.

MODEL CODE REUSABILITY (MCR): Model code should be generalised for reuse in varying situations.

PREDICTION QUALITY (PQ): Workflow changes may affect performance.

MACHINE LEARNING RELIABILITY (MLRelia): Model functionality depends on data quality; robustness measures should be in place.

PROTOTYPE (Proto): Deploying small-scale prototypes into full systems can be dangerous.
""".strip()

PROMPT_TAIL = f"""Please determine which type of ML Self-Admitted Technical Debt (SATD) the following Code Comment belongs to. 
You MUST answer with **only ONE** abbreviation from:
{', '.join(sorted(ABBR_SET))}
""".strip()

def build_prompt(comment: str) -> str:
    return (
        f"{PROMPT_HEAD}\n\n{PROMPT_TAIL}\n\n"
        "Code Comment:\n"
        f"```text\n{comment}\n```\n\n"
        "#Abbreviation:"
    )

def extract_abbr_from_text(text: str) -> str:
    if not text:
        return "<UNK>"
    cz = _canon(text)
    canon_map = {_canon(a): a for a in ABBR_SET}
    if cz in canon_map:
        return canon_map[cz]
    for abbr in ABBR_SET:
        pat = r'\b' + re.sub(r'\s+', r'\\s*', re.escape(abbr)) + r'\b'
        if re.search(pat, text, flags=re.IGNORECASE):
            return abbr
    for full, abbr in FULL2ABBR.items():
        pat = r'\b' + re.sub(r'\s+', r'\\s*', re.escape(full)) + r'\b'
        if re.search(pat, text, flags=re.IGNORECASE):
            return abbr
    return "<UNK>"

# -------- 3. 加载模型（保持不变） --------
print("[INFO] Loading model …")
pipe = pipeline(
    "text-generation",
    model=MODEL_PATH,
    torch_dtype="auto",
    device_map="auto",
)

# ============ 4. reason 的提示与解析（强制成功；不使用本地默认兜底） ============
REASON_SYS_1 = (
    "You are a concise classifier. Think silently. "
    "Reply with ONE paragraph that starts with 'REASON:' followed by a short justification (<= 512 words)."
)
REASON_SYS_2 = (
    "Return exactly ONE paragraph. It must start with 'REASON:' then a short justification (<= 512 words). "
    "No preface, no label, no markdown."
)
REASON_SYS_FORCE = (
    "Output exactly ONE paragraph starting with 'REASON:' followed by a brief justification (<= 512 words). "
    "Ground it in the comment text. No label names, no category names, no markdown, no quotes."
)

def build_reason_prompt(comment: str, abbr: str) -> str:
    # 已确定的类别仅作为上下文，不要求模型复述标签
    return (
        "You have already chosen the ML-SATD abbreviation: " + abbr + ".\n"
        "Provide a brief human-readable justification grounded in the comment content.\n"
        "Format strictly:\n"
        "REASON: <short sentence>\n\n"
        "Code Comment:\n"
        f"```text\n{comment}\n```"
    )

def _extract_visible(content: str) -> str:
    if not isinstance(content, str):
        return ""
    # 去除可能的 <think>…</think>
    content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL | re.IGNORECASE)
    # 若含 assistantfinal，取其后内容
    m = re.search(r"assistantfinal\s*(.*)$", content, flags=re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else content.strip()

def parse_reason(text: str) -> str:
    body = _extract_visible(text)
    # 1) 优先抓 "REASON:"
    m = re.search(r"(?:^|\n)\s*REASON\s*[:：]\s*(.+)", body, flags=re.IGNORECASE)
    cand = None
    if m:
        cand = m.group(1).strip()
    else:
        # 2) 退化为“第一句非空文本”（仍是模型生成），避免空值
        lines = [ln.strip() for ln in body.splitlines() if ln.strip()]
        if lines:
            cand = lines[0]
    if not cand:
        return ""
    cand = re.sub(r'^[\'"`“”]+|[\'"`“”]+$', '', cand).strip()
    # 控长度：太长则截断为一句
    cand = re.split(r'(?<=[.。!?])\s+', cand)[0].strip()
    return cand[:400]

@torch.inference_mode()
def generate_reason(comment: str, abbr: str) -> str:
    # 1) 首次尝试
    msgs1 = [
        {"role": "system", "content": REASON_SYS_1},
        {"role": "user", "content": build_reason_prompt(comment, abbr)},
    ]
    out1 = pipe(msgs1, max_new_tokens=REASON_MAX_NEW_TOKENS)
    content1 = out1[0]["generated_text"][-1]["content"]
    reason1 = parse_reason(content1)
    if len(reason1) >= 3:
        return reason1

    # 2) 第二次加强约束
    msgs2 = [
        {"role": "system", "content": REASON_SYS_2},
        {"role": "user", "content": build_reason_prompt(comment, abbr)},
    ]
    out2 = pipe(msgs2, max_new_tokens=REASON_MAX_NEW_TOKENS)
    content2 = out2[0]["generated_text"][-1]["content"]
    reason2 = parse_reason(content2)
    if len(reason2) >= 3:
        return reason2

    # 3) 强制格式：仍由模型生成，但更刚性
    msgs3 = [
        {"role": "system", "content": REASON_SYS_FORCE},
        {"role": "user", "content": build_reason_prompt(comment, abbr)},
    ]
    out3 = pipe(msgs3, max_new_tokens=REASON_MAX_NEW_TOKENS)
    content3 = out3[0]["generated_text"][-1]["content"]
    reason3 = parse_reason(content3)
    # 最终保证非空（若仍空，则取模型完整可见体的第一行作为理由——依然是模型生成的文本）
    if len(reason3) < 1:
        reason3 = _extract_visible(content3).splitlines()[0].strip() if _extract_visible(content3) else "Model-generated reason."
    return reason3[:400]

# -------- 5. 分类函数（保持你的做法与参数） --------
@torch.inference_mode()
def classify(comment: str):
    messages = [
        {"role": "system", "content":
         "You are a strict classifier. Reasoning: high. "
         "Output ONLY the abbreviation, one line."},
        {"role": "user", "content": build_prompt(comment)},
    ]
    outputs = pipe(messages, max_new_tokens=MAX_NEW_TOKENS)
    answer = outputs[0]["generated_text"][-1]['content']
    raw_answer = answer.split('assistantfinal')[-1] if 'assistantfinal' in answer else answer
    abbr = extract_abbr_from_text(raw_answer)
    return abbr, raw_answer

# -------- 6. 主流程 --------
df = pd.read_csv(CSV_PATH)

rows = []
unk_cnt = 0
gold_unmapped = 0

print("[INFO] Classifying …")
for cmt, gold in tqdm(zip(df["Comment Text"], df["ML TD Type"]),
                      total=len(df), ncols=80):
    real_full = normalize_to_full(str(gold))
    if real_full is None:
        gold_unmapped += 1
        continue

    abbr, raw = classify(str(cmt))
    pred_full = ABBR2FULL.get(abbr, None)
    if pred_full is None:
        unk_cnt += 1
        if PRINT_UNPARSED:
            with open(RUN_DIR/"unparsed.txt", "a", encoding="utf-8") as f:
                f.write(raw + "\n")
        pred_full = ABBR2FULL[FALLBACK_ABBR]
        abbr = FALLBACK_ABBR

    # 强制让模型产出 reason（不采用本地默认文本）
    reason = generate_reason(str(cmt), abbr)

    rows.append({
        "comment": cmt,
        "real": real_full,
        "pred": pred_full,
        "raw_output": raw,
        "reason": reason,             # 新增列：始终非空，由模型生成
    })

pred_df = pd.DataFrame(rows)

if pred_df.empty:
    print("\n[WARN] No valid samples after label normalization. "
          "Please check the dataset's label names (column 'ML TD Type').")
else:
    report_text = classification_report(
        pred_df["real"], pred_df["pred"],
        labels=LABELS, zero_division=0, digits=3
    )
    print("\n[INFO] Overall metrics:\n", report_text)

    pred_df.to_csv(RUN_DIR/"predictions.csv", index=False)

    cm = confusion_matrix(pred_df["real"], pred_df["pred"], labels=LABELS)
    pd.DataFrame(cm, index=LABELS, columns=LABELS).to_csv(RUN_DIR/"confusion_matrix.csv")

    report_dict = classification_report(
        pred_df["real"], pred_df["pred"],
        labels=LABELS, zero_division=0, output_dict=True
    )
    rep_df = pd.DataFrame(report_dict).transpose()
    rep_df.index.name = "label"
    rep_df = rep_df.reset_index()
    rep_df["info"] = ""

    info_lines = [
        f"Unrecognized outputs mapped to '{FALLBACK_ABBR}': {unk_cnt}",
        f"Gold labels unmapped (skipped): {gold_unmapped}",
        f"Total evaluated samples: {len(pred_df)} / original {len(df)}"
    ]
    rep_df.loc[len(rep_df)] = {
        "label": "[INFO]",
        "precision": "",
        "recall": "",
        "f1-score": "",
        "support": "",
        "info": " | ".join(info_lines)
    }
    rep_df.to_csv(RUN_DIR/"report.csv", index=False)

print(f"\n[INFO] Files saved in {RUN_DIR}")
print(f"[INFO] Unrecognized mapped to '{FALLBACK_ABBR}': {unk_cnt}")
print(f"[INFO] Gold labels unmapped (skipped): {gold_unmapped}")

gc.collect(); torch.cuda.empty_cache()
